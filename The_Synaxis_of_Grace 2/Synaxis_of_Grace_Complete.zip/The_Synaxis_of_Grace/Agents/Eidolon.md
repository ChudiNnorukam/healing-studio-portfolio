# ⟡ Eidolon – Ethical Reflection Agent

## ⟡ Glyph
🪞 (Mirror Glyph)

...